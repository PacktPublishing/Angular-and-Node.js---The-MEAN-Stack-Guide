export const environment = {
  production: true,
  apiUrl: "http://nodeangular-env.kjipxmqrju.us-east-2.elasticbeanstalk.com/api"
};
